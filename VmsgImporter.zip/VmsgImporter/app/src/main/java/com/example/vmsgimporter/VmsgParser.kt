package com.example.vmsgimporter

import java.io.ByteArrayOutputStream
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.Locale

data class VmsgMessage(
    val address: String,
    val body: String,
    val date: Long,
    /** 1 = received (inbox), 2 = sent */
    val type: Int,
    val read: Boolean
)

/**
 * Tolerant .vmsg (vMessage 1.1) parser. Handles the layout written by Oppo/ColorOS,
 * Nokia and most Android backup tools: BEGIN:VMSG / VCARD(TEL) / VENV / VBODY,
 * quoted-printable bodies, multi-line bodies and several date formats.
 */
object VmsgParser {

    private val dateFormats = listOf(
        "yyyy.MM.dd HH:mm:ss",
        "yyyy/MM/dd HH:mm:ss",
        "yyyy-MM-dd HH:mm:ss",
        "yyyy.MM.dd HH:mm",
        "yyyy/MM/dd HH:mm",
        "yyyy-MM-dd HH:mm",
        "yyyyMMdd'T'HHmmss",
        "dd/MM/yyyy HH:mm:ss"
    )

    private val bodyHeader = Regex("^(?i)(subject|x-body|body)([^:]*):(.*)$")

    fun parse(raw: String): List<VmsgMessage> {
        val lines = raw.removePrefix("﻿").replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val out = ArrayList<VmsgMessage>()

        var inMsg = false
        var inBody = false
        var box = 1
        var read = true
        var tel = ""
        var date = 0L
        var body = StringBuilder()
        var bodyHasText = false

        fun reset() {
            inMsg = false; inBody = false; box = 1; read = true
            tel = ""; date = 0L; body = StringBuilder(); bodyHasText = false
        }

        var i = 0
        while (i < lines.size) {
            var line = lines[i]
            i++
            val upper = line.trim().uppercase(Locale.ROOT)

            when {
                upper == "BEGIN:VMSG" -> { reset(); inMsg = true }
                upper == "END:VMSG" -> {
                    if (inMsg && tel.isNotBlank()) {
                        out.add(
                            VmsgMessage(
                                address = tel,
                                body = body.toString().trimEnd('\n'),
                                date = if (date > 0) date else System.currentTimeMillis(),
                                type = box,
                                read = read
                            )
                        )
                    }
                    reset()
                }
                !inMsg -> Unit
                upper == "BEGIN:VBODY" -> inBody = true
                upper == "END:VBODY" -> inBody = false
                inBody -> {
                    if (upper.startsWith("DATE:") || upper.startsWith("DATE;")) {
                        date = parseDate(line.substringAfter(':').trim())
                    } else {
                        val m = bodyHeader.matchEntire(line)
                        if (m != null) {
                            val params = m.groupValues[2].uppercase(Locale.ROOT)
                            var value = m.groupValues[3]
                            val qp = params.contains("QUOTED-PRINTABLE")
                            val charset = Regex("CHARSET=([\\w-]+)").find(params)?.groupValues?.get(1) ?: "UTF-8"
                            if (qp) {
                                while (value.endsWith("=") && i < lines.size) {
                                    value = value.dropLast(1) + lines[i]
                                    i++
                                }
                                value = decodeQuotedPrintable(value, charset)
                            }
                            if (bodyHasText) body.append('\n')
                            body.append(value)
                            bodyHasText = true
                        } else if (bodyHasText || line.isNotBlank()) {
                            if (bodyHasText) body.append('\n')
                            body.append(line)
                            bodyHasText = true
                        }
                    }
                }
                else -> {
                    when {
                        upper.startsWith("TEL") && tel.isEmpty() -> {
                            tel = line.substringAfter(':').trim()
                        }
                        upper.startsWith("X-IRMC-BOX:") || upper.startsWith("X-BOX:") -> {
                            val v = line.substringAfter(':').trim().uppercase(Locale.ROOT)
                            box = if (v.contains("SEND") || v.contains("SENT") || v.contains("OUT")) 2 else 1
                        }
                        upper.startsWith("X-IRMC-STATUS:") -> {
                            read = !line.substringAfter(':').trim().equals("UNREAD", ignoreCase = true)
                        }
                    }
                }
            }
        }
        return out
    }

    fun parseDate(s: String): Long {
        for (f in dateFormats) {
            try {
                val sdf = SimpleDateFormat(f, Locale.US)
                sdf.isLenient = false
                return sdf.parse(s)!!.time
            } catch (_: Exception) {
            }
        }
        return 0L
    }

    fun decodeQuotedPrintable(s: String, charsetName: String): String {
        val bos = ByteArrayOutputStream()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '=' && i + 2 < s.length + 0 && isHex(s[i + 1]) && isHex(s[i + 2])) {
                bos.write(s.substring(i + 1, i + 3).toInt(16))
                i += 3
            } else {
                bos.write(c.toString().toByteArray(Charsets.UTF_8))
                i++
            }
        }
        val cs = try { Charset.forName(charsetName) } catch (_: Exception) { Charsets.UTF_8 }
        return String(bos.toByteArray(), cs)
    }

    private fun isHex(c: Char) = c in '0'..'9' || c in 'A'..'F' || c in 'a'..'f'
}
