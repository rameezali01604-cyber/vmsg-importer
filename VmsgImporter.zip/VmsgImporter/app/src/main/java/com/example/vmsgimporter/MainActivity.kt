package com.example.vmsgimporter

import android.Manifest
import android.app.Activity
import android.app.role.RoleManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var pickButton: Button
    private var busy = false

    private val roleLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { refresh() }

    private val pickFile =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) startImport(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        status = TextView(this).apply { textSize = 16f }
        root.addView(status)

        val defaultBtn = Button(this).apply {
            text = "1. Set this app as default SMS app"
            setOnClickListener { requestDefaultSms() }
        }
        root.addView(defaultBtn)

        pickButton = Button(this).apply {
            text = "2. Choose .vmsg file and import"
            setOnClickListener { pickFile.launch(arrayOf("*/*")) }
        }
        root.addView(pickButton)

        val restoreBtn = Button(this).apply {
            text = "3. Switch back to your normal messages app"
            setOnClickListener { startActivity(Intent(android.provider.Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS)) }
        }
        root.addView(restoreBtn)

        log = TextView(this).apply { textSize = 13f; setPadding(0, pad, 0, 0) }
        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            addView(log)
        }
        root.addView(scroll)
        setContentView(root)

        val needed = arrayOf(Manifest.permission.READ_SMS, Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS)
        if (needed.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, needed, 1)
        }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun isDefault() = Telephony.Sms.getDefaultSmsPackage(this) == packageName

    private fun refresh() {
        status.text = if (isDefault())
            "Ready: this app is the default SMS app. Choose your .vmsg file."
        else
            "Step 1 needed: Android only lets the default SMS app write messages."
        pickButton.isEnabled = isDefault() && !busy
    }

    private fun requestDefaultSms() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            roleLauncher.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
        } else {
            val i = Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
            i.putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, packageName)
            roleLauncher.launch(i)
        }
    }

    private fun append(text: String) {
        runOnUiThread { log.append(text + "\n") }
    }

    private fun startImport(uri: Uri) {
        if (!isDefault()) { refresh(); return }
        busy = true
        refresh()
        log.text = ""
        append("Reading file...")
        Thread {
            try {
                val text = contentResolver.openInputStream(uri)!!.use { it.readBytes() }.toString(Charsets.UTF_8)
                val messages = VmsgParser.parse(text)
                append("Found ${messages.size} messages.")
                if (messages.isEmpty()) {
                    append("Nothing to import. The file may use a layout this app does not recognise.")
                } else {
                    val r = SmsImporter.import(this, messages) { done, total ->
                        runOnUiThread { status.text = "Importing $done / $total" }
                    }
                    append("Imported: ${r.imported}")
                    append("Skipped (already on phone): ${r.skipped}")
                    append("Failed: ${r.failed}")
                    append("Done. Now tap step 3 to switch back to your normal messages app.")
                }
            } catch (e: Exception) {
                append("Error: ${e.message}")
            } finally {
                busy = false
                runOnUiThread { refresh() }
            }
        }.start()
    }
}
