package com.example.vmsgimporter

import android.content.ContentValues
import android.content.Context
import android.provider.Telephony

data class ImportResult(val imported: Int, val skipped: Int, val failed: Int)

object SmsImporter {

    /**
     * Inserts messages into the system SMS provider. Only works while this app is the
     * default SMS app. Messages already present (same number, time and text) are skipped,
     * so running the import twice does not create duplicates.
     */
    fun import(
        context: Context,
        messages: List<VmsgMessage>,
        onProgress: (done: Int, total: Int) -> Unit
    ): ImportResult {
        val resolver = context.contentResolver
        val existing = HashSet<String>()
        resolver.query(
            Telephony.Sms.CONTENT_URI,
            arrayOf(Telephony.Sms.ADDRESS, Telephony.Sms.DATE, Telephony.Sms.BODY),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                existing.add(key(c.getString(0), c.getLong(1), c.getString(2)))
            }
        }

        var imported = 0
        var skipped = 0
        var failed = 0

        messages.forEachIndexed { index, m ->
            val k = key(m.address, m.date, m.body)
            if (!existing.add(k)) {
                skipped++
            } else {
                val values = ContentValues().apply {
                    put(Telephony.Sms.ADDRESS, m.address)
                    put(Telephony.Sms.BODY, m.body)
                    put(Telephony.Sms.DATE, m.date)
                    put(Telephony.Sms.DATE_SENT, m.date)
                    put(Telephony.Sms.READ, if (m.read) 1 else 0)
                    put(Telephony.Sms.SEEN, 1)
                    put(Telephony.Sms.TYPE, m.type)
                }
                val uri = if (m.type == 2) Telephony.Sms.Sent.CONTENT_URI else Telephony.Sms.Inbox.CONTENT_URI
                try {
                    if (resolver.insert(uri, values) != null) imported++ else failed++
                } catch (e: Exception) {
                    failed++
                }
            }
            if (index % 25 == 0 || index == messages.lastIndex) onProgress(index + 1, messages.size)
        }
        return ImportResult(imported, skipped, failed)
    }

    private fun key(address: String?, date: Long, body: String?): String {
        val digits = (address ?: "").filter { it.isDigit() }.takeLast(9)
        return "$digits|${date / 1000}|${body ?: ""}"
    }
}
